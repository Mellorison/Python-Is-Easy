Artist = 'Soundgarden'    

SoloArtist = 'False'

StillActive = "Unknown"

YearFormed = 1984

MusicansBand = True

print(MusicansBand)

if Artist == "Soundgarden":   

    MusicansBand = "Soundgarden is a Quartet Grunge band formed in 1984"  

    YearFormed = print(int("1984"))  

elif Artist == "Chris Cornel, Kim Thayil, Matt Cameron, Ben Shepherd":

    MusicansBand = "Soundgarden is a Quartet Grunge band formed in 1984"     

else:                          
    MusicansBand = "Not Quartet"  

print(MusicansBand)               